#
using RDatasets, Statistics, StatsBase, Plots, Random
#
include("ssb-inf.jl")

bdata=housing()

# regular matrix format: 1-13 are independent variables, 14 is dependent variable.
#
#    1. CRIM      per capita crime rate by town
#    2. ZN        proportion of residential land zoned for lots over
#                 25,000 sq.ft.
#    3. INDUS     proportion of non-retail business acres per town
#    4. CHAS      Charles River dummy variable (= 1 if tract bounds
#                 river; 0 otherwise)
#    5. NOX       nitric oxides concentration (parts per 10 million)
#    6. RM        average number of rooms per dwelling
#    7. AGE       proportion of owner-occupied units built prior to 1940
#    8. DIS       weighted distances to five Boston employment centres
#    9. RAD       index of accessibility to radial highways
#    10. TAX      full-value property-tax rate per $10,000
#    11. PTRATIO  pupil-teacher ratio by town
#    12. B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks
#                 by town
#    13. LSTAT    % lower status of the population
#    14. MEDV     Median value of owner-occupied homes in $1000's
###

xfull=bdata[1]'
yfull=bdata[2]'

# selecting the same 4 variables from Fan & Jiang (2005)
xmat=hcat(xfull[:, 6],log.(xfull[:,10]),xfull[:,11], log.(xfull[:,13]))
y=yfull

 n, p=size(xmat)

Ngrid=401
intgridmat=zeros(Ngrid,p)
for j in 1:p
intgridmat[:,j]=range(minimum(xmat[:,j]),maximum(xmat[:,j]),length=Ngrid)
end

#
optmodel=optbwd(xmat,y,intgridmat)

# removing outliers
te=y .- optmodel["fit"]
noutind=findall(x -> (-11 < x < 12), vec(te))
#
xfull=xfull[noutind,:]
yfull=yfull[noutind]
# random sample of 200 observations
Random.seed!(202103)
ind=sample(1:size(xfull)[1],200)
# selecting the same 4 variables from Fan & Jiang (2005)
xmat=hcat(xfull[ind, 6],log.(xfull[ind,10]),xfull[ind,11], log.(xfull[ind,13]))
y=yfull[ind]

 n, p=size(xmat)

Ngrid=401
intgridmat=zeros(Ngrid,p)
for j in 1:p
intgridmat[:,j]=range(minimum(xmat[:,j]),maximum(xmat[:,j]),length=Ngrid)
end

#
optmodel=optbwd(xmat,y,intgridmat)



##

# testplot
using Plots
plot(xmat,optmodel["mu"][:,2:5],seriestype=:line, layout=(2,2))
plot(xmat,optmodel["parmet"][:,2:5],seriestype=:line, layout=(2,2))

##
# partial residual plots
parred=zeros(n,p)
for j in 1:p
parred[:,j]=y-sum(optmodel["mu"][:,1:end .!=j+1],dims=2)
end
mu= optmodel["mu"]
pbeta=optmodel["parmet"]
mustar=optmodel["mustar"]

l=@layout [a b; c d]

p1= plot(xmat[:,1],[parred[:,1] mu[:,2] pbeta[:,2] mustar[:,1]],seriestype=[:scatter :line :line :line],legend=false,linestyle=[ :dash :solid :dot],lw=2,xlabel="RM",ylabel="additive residual",title="(a)")

p2= plot(xmat[:,2],[parred[:,2] mu[:,3] pbeta[:,3] mustar[:,2]],seriestype=[:scatter :line :line :line],legend=false,linestyle=[ :dash :solid :dot],lw=2,xlabel="log(TAX)",ylabel="additive residual",title="(b)")

p3= plot(xmat[:,3],[parred[:,3] mu[:,4] pbeta[:,4] mustar[:,3]],seriestype=[:scatter :line :line :line],legend=false,linestyle=[ :dash :solid :dot],lw=2,xlabel="PTRATIO",ylabel="additive residual",title="(c)")

p4= plot(xmat[:,4],[parred[:,4] mu[:,5] pbeta[:,5] mustar[:,4]],seriestype=[:scatter :line :line :line],legend=false,linestyle=[ :dash :solid :dot],lw=2,xlabel="log(LSTAT)",ylabel="additive residual",title="(d)")

plot(p1,p2,p3,p4, layout=l)

savefig("b200pr.pdf")



## conditional bootstrap for power analysis
### for hypothesis 1 (same as in Fan 2005)
# different bandwidth choices
ncboot=1000
bwopt=optmodel["bwd"]
bwdcom=zeros(5,p)

bwdcom[1,:]=bwopt ./ 2
bwdcom[2,:]=2 .* bwopt ./3
bwdcom[3,:]=bwopt
bwdcom[4,:]=3 .* bwopt ./ 2
bwdcom[5,:]=2 .* bwopt
#
rss1=zeros(5)
rss0=zeros(5)
lambda=zeros(5)
Q1=zeros(5)
Q2=zeros(5)
Q3=zeros(5)
Q4=zeros(5)
bplambda=zeros(5)
bpq1=zeros(5)
bpq2=zeros(5)
bpq3=zeros(5)
bpq4=zeros(5)
#
lambdastar=zeros(ncboot,5)
Q1star= zeros(ncboot,5)
Q2star= zeros(ncboot,5)
Q3star= zeros(ncboot,5)
Q4star= zeros(ncboot,5)
# loop for bandwidths
for j in 1:5
# calculation of test statistics for the original data
bwur=bwdcom[j,:]
urmodel=ssb(xmat,y,intgridmat,bwur)
fitur=urmodel["fit"]
#bwur=uresm["bwd"]
# restricted model data
rind=[2 3 4]
xmat_res=xmat[:, 1]
intgridmat_res=intgridmat[:,1]
# h star matrix for the nonparametric component 1
Hmat1=hstar(xmat_res,intgridmat_res,bwur[1])[1]
# for parametric null hypothesis
xcmat_rp=reshape(xmat[:,rind],n,length(rind))
xmat_res_pm=hcat(ones(n,1), xcmat_rp .- mean(xcmat_rp,dims=1))
# two step semiparametric model
betahat=xmat_res_pm \ y
mu1=Hmat1*(y-xmat_res_pm*betahat)
betahat=xmat_res_pm \(y-mu1)
mu1=Hmat1*(y-xmat_res_pm*betahat)
#

fitr=mu1+xmat_res_pm*betahat

rss1[j]=sum((y .- fitur) .^ 2)
rss0[j]=sum((y .- fitr) .^ 2)

### chi-square statistics
lambda[j]= n/2 * (rss0[j]-rss1[j])/rss1[j]
Q1[j]= n* sum(linex.(1e-6,1,fitur-fitr))/rss1[j]
 Q2[j]= n* sum(linex.(0.2,1,fitur-fitr))/rss1[j]
 Q3[j]= n* sum(linex.(0.5,1,fitur-fitr))/rss1[j]
 Q4[j]= n* sum(linex.(1,1,fitur-fitr))/rss1[j]

#
epsi_ures=y .- fitur

cen_epsi_ures=epsi_ures .- mean(epsi_ures)

# loop through number of bootstraps

#
for i in 1:ncboot
ystar =  fitr .+ sample(cen_epsi_ures,n) #sum(uresm["mu"][:,1:end .!= rind+1],dims=2)
# bootstrapped
uresmstar= ssb(xmat,ystar,intgridmat,bwur)
betahatstar=xmat_res_pm \ ystar
mu1star=Hmat1*(ystar-xmat_res_pm*betahatstar)
betahatstar=xmat_res_pm \(ystar-mu1star)
mu1star=Hmat1*(ystar-xmat_res_pm*betahatstar)

#

fitrstar=mu1star+xmat_res_pm*betahatstar


rss1star=sum((ystar .- uresmstar["fit"]) .^ 2)
rss0star=sum((ystar .- fitrstar) .^ 2)

lambdastar[i,j]= n/2 * (rss0star-rss1star)/rss1star
#
Q1star[i,j]= n* sum(linex.(1e-6,1,uresmstar["fit"]-fitrstar))/rss1star
Q2star[i,j]= n* sum(linex.(0.2,1,uresmstar["fit"]-fitrstar))/rss1star
Q3star[i,j]= n* sum(linex.(0.5,1,uresmstar["fit"]-fitrstar))/rss1star
Q4star[i,j]= n* sum(linex.(1,1,uresmstar["fit"]-fitrstar))/rss1star
end

cbstat=convert(DataFrame,hcat(lambdastar,Q1star, Q2star, Q3star, Q4star))
#
bplambda[j]=mean(lambda[j] .<= lambdastar[:,j])
bpq1[j]=mean(Q1[j] .<= Q1star[:,j])
bpq2[j]=mean(Q2[j] .<= Q2star[:,j])
bpq3[j]=mean(Q3[j] .<= Q3star[:,j])
bpq4[j]=mean(Q4[j] .<= Q4star[:,j])
#
# end of bootstrap
end

##
